package LMS.LearningManagementSystem.model;

public class ShortAnswerQuestion extends Question {
}
