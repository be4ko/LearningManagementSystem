package LMS.LearningManagementSystem.model;

public enum Role {
    Student,
    Instructor,
    Admin
}