package LMS.LearningManagementSystem.configuration;

import LMS.LearningManagementSystem.model.Course;
import LMS.LearningManagementSystem.model.Instructor;
import LMS.LearningManagementSystem.model.Role;
import LMS.LearningManagementSystem.repository.CourseRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import LMS.LearningManagementSystem.repository.InstructorRepository;

import java.util.List;

@Configuration
public class CourseConfig {
//    @Bean (name = "courseCommandLineRunner")
//    CommandLineRunner commandLineRunner(CourseRepository repository, InstructorRepository instructorRepository) {
//        Instructor ali = new Instructor(554,"Basher","Basher280@gmail","123123", Role.Instructor);
//        Instructor omar = new Instructor(996,"Lamia","Lamia@gmail","123123",Role.Instructor);
//        // Save instructors first
//        instructorRepository.saveAll(List.of(ali, omar));
//        return args -> {
//            Course Software = new Course("Software","jkdsbhbcs",5,ali);
//            Course Datastructures = new Course("Data Structure","cdhjvhjv",6,omar);
//            repository.saveAll(List.of(Software,Datastructures));
//        };
//    }
}