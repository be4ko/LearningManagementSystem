package LMS.LearningManagementSystem.service;

import LMS.LearningManagementSystem.model.*;
import LMS.LearningManagementSystem.repository.QuizLogRepository;
import LMS.LearningManagementSystem.repository.QuizRepository;
import LMS.LearningManagementSystem.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    private final StudentRepository studentRepository;
    private final QuizRepository quizRepository;
    private final QuizLogRepository quizLogRepository;
    private final NotificationService notificationService;

    @Autowired
    public StudentService(StudentRepository studentRepository, QuizRepository quizRepository, QuizLogRepository quizLogRepository, NotificationService notificationService) {
        this.studentRepository = studentRepository;
        this.quizRepository = quizRepository;
        this.quizLogRepository = quizLogRepository;
        this.notificationService = notificationService;
    }

    public List<Student> getStudents(){ // مفروض ترجع من الDatabase
        return studentRepository.findAll();
    }

    public Quiz getQuiz(Integer quizId, Integer studentId) {
        Student student = studentRepository.findById(studentId).orElseThrow(() -> new IllegalArgumentException("Student not found"));
        Quiz quiz = quizRepository.findById(quizId).orElseThrow(() -> new IllegalArgumentException("Quiz not found."));

        return quiz;
    }

    public String takeQuiz(Integer studentId, Integer quizId, List<String> answers) {
        Student student = studentRepository.findById(studentId).orElseThrow(() -> new IllegalArgumentException("Course not found"));
        Quiz quiz = quizRepository.findById(quizId).get();

        int i = 0, score = 0;
        for (Question question : quiz.getQuestions()) {
            if (question.isCorrect(answers.get(i++))) score+= question.getGrade();
        }
        QuizLog attempt = new QuizLog();
        attempt.setScore(score);
        attempt.setQuiz(quiz);
        attempt.setStudentAnswers(answers);
        attempt.setAttemptDate(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant()));
        attempt.setStudent(student);
        quizLogRepository.save(attempt);
        String feedback = "Your score in " + quiz.getTitle()+" is "+ score + " out of " + quiz.getTotalGrade() + " in " + quiz.getCourse().getCourseTitle();
        notificationService.createNotification(studentId, Role.Student,feedback);
        attempt.setFeedback(feedback);
        return feedback;
    }
}