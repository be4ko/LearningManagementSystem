package LMS.LearningManagementSystem.configuration;

import LMS.LearningManagementSystem.model.Course;
import LMS.LearningManagementSystem.model.Instructor;
import LMS.LearningManagementSystem.model.Lesson;
import LMS.LearningManagementSystem.model.Role;
import LMS.LearningManagementSystem.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class LessonConfig {

    // Example for a repository configuration if necessary
    @Bean (name = "lessonCommandLineRunner")
    CommandLineRunner commandLineRunner(LessonRepository repository, CourseRepository courseRepository,InstructorRepository instructorRepository){
        Instructor ali = new Instructor(554,"Basher","Basher280@gmail","123123",Role.Instructor);
        Instructor omar = new Instructor(996,"Lamia","Lamia@gmail","123123",Role.Instructor);
        // Save instructors first
        instructorRepository.saveAll(List.of(ali, omar));
        Course Software = new Course("Software","jkdsbhbcs",5,ali);
        Course Datastructures = new Course("Data Structure","cdhjvhjv",6,omar);
        courseRepository.saveAll(List.of(Software, Datastructures));
        return args -> {
            Lesson one = new Lesson( "m", "123j", Software);
            Lesson two = new Lesson( "n", "123o", Software);
            repository.saveAll(List.of(one,two));
        };
    }
}
