package LMS.LearningManagementSystem.model;

public class TrueFalseQuestion extends Question {
}
